export class DetailOrder {
  detailOrder_id: number;
  barcode: string;
  purchasePrice: string;
  quantity: number;
  order_id: number;
  pro_id: number;
}
