export class Transaction {
  tra_id: number;
  tra_type: string;
  voucherNo: string;
  description: string;
  barcode: string;
  totalQty: number;
  totalAmount: number;
  user_id: number;
  acc_id: number;
}
