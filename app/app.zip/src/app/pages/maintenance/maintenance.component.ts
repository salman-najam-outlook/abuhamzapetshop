import { Component } from '@angular/core';

@Component({
  selector: 'ngx-maintenance',
  template: `<router-outlet></router-outlet>`,
})
export class MaintenanceComponent {
}
