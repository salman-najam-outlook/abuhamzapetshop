import { Component } from '@angular/core';

@Component({
  selector: 'ngx-form-reports',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ReportsComponent {
}
