import { Component } from '@angular/core';

@Component({
  selector: 'ngx-form-products',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ProductsComponent {
}
