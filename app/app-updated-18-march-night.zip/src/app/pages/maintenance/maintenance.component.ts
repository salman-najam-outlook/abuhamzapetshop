import { Component } from '@angular/core';

@Component({
  selector: 'ngx-form-maintenance',
  template: `<router-outlet></router-outlet>`,
})
export class MaintenanceComponent {
}
