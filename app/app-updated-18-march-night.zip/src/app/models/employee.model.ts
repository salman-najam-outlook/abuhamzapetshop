export class Employee {
  emp_id: number;
  name: string;
  NIC: string;
  contact: string;
  address: string;
  salary: number;
  date: Date;
}
