export class User {
  user_id: number;
  firstname: string = "";
  lastname: string = "";
  username: string = "";
  password: string = "";
  userRoll: string = "";
  status: string = "";
  email: string = "";
  contact: number;
}
