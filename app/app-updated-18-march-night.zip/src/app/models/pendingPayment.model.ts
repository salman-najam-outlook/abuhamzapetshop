export class PendingPayments {
    vch_id: number;
    vchNo: string;
    date: string;
    pendingAmount: number;
    paidAmount: number;
    totalAmount: number;
    status: string;
    vchType: string;
    SupplierName: string;
}