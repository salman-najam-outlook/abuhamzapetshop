export class Payment {
    voucherNumber: string;
    amountPaid: number;
    supplierId: number;
}