export class Advance {
  advance_id: number;
  date: Date;
  amount: number;
  barcode: string;
  cus_id: number;
  cus_Name: string;
  cus_No: string;
  description: string;
}
