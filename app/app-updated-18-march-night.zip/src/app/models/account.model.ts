export class Account {
  acc_id: number;
  balance: number;
  name: string;
  AccType_id: number;
}
