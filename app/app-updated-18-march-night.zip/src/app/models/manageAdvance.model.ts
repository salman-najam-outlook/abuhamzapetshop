export class ManageAdvance {
  voucherNo: string;
  amount: number;
  transactionType: number;
}