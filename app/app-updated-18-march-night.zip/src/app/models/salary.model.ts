export class Salary {
  sal_id: number;
  amount: number;
  date: Date;
  emp_id: number;
}
