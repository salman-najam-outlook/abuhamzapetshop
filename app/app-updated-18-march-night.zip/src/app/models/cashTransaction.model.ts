export class CashTransaction {
  debitor_Account_Id: number;
  creditor_Account_Id: number;
  voucherAmount: number;
  description: string;
}
