export class Supplier {
  sup_id: number;
  name: string;
  company: string;
  contact: string;
  date: Date;
}
