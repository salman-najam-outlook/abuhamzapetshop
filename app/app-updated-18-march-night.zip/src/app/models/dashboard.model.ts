export class Dashboard {
  cashInDrawer: number;
  pettyCash: number;
  expenses: number;
  purchases: number;
  totalPurchase: number;
  totalSale: number;
  sales: number;
  loans: number;
  advances: number;
  purchasePendings: number;
  totalSuppliers: number;
  totalCustomers: number;
}
