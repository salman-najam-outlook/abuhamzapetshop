export class Category {
  cat_id: number;
  name: string;
  mainCat_id: number;
}
