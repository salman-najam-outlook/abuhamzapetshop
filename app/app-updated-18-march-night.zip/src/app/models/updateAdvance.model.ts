export class UpdateAdvance {
    voucherNo: string = "";
    totalAdvance: number = 0;
    remainingAdvance: number = 0;
  }