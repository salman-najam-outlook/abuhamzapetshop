export class SubCategory {
  subCat_id: number;
  name: string;
  cat_id: number;
}
