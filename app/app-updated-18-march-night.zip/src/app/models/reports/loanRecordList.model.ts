export class LoanRecordList {
  date: Date;
  vchNo: string;
  pendingAmount: string;
  paidAmount: string;
  totalAmount: string;
  status: string;
  vchType: string;
  description: string;
  customerName: string;
  customerNo: string;
}
