export class SaleRecordList {
  vchNo: string;
  date: Date;
  pendingAmount: number;
  paidAmount: number;
  totalAmount: number;
  status: string;
  vchType: string;
  description: string;
}
