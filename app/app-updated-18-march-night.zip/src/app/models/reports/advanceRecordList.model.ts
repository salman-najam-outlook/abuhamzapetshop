export class AdvanceRecordList {
  date: Date;
  amount: number;
  barcode: string;
  cus_No: string;
  description: string;
  cus_Name: string;
  voucherNo: string;
}
