export class PurchasePendingList {
  date: Date;
  vchNo: string;
  pendingAmount: string;
  paidAmount: string;
  totalAmount: string;
  status: string;
  vchType: string;
  description: string;
  supplierName: string;
  supplierNo: string;
}
