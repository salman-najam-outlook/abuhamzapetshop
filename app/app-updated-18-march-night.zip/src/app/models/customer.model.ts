export class Customer {
  cus_id: number;
  name: string;
  contact: string;
  date: Date;
}
