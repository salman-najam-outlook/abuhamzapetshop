export class Category {
  invoice_id: number;
  date: Date;
  discount: number;
  totalAmount: number;
  AmountTendered: number;
  change: number;
  user_id: number;
  tra_id: number;
}
