export class FourthSubCategory {
  fsubCat_id: number;
  name: string;
  subCat_id: number;
}
