export class Product {
  pro_id: number;
  barcode: string;
  name: string;
  description: string;
  purchase_price: number;
  sell_price: number;
  quantity: number;
  fsubCat_id: number;
  subCat_id: number;
  cat_id: number;
  mainCat_id: number;
}
