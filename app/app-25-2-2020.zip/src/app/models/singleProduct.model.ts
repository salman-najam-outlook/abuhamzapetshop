export class SingleProduct {
    barcode: string = '';
    productName: string = '';
    purchasePrice: number = 0;
    quantity: number = 0;
    totalAmount: number = 0;
    sellPrice: number = 0;
}