export class MainCategory {
  mainCat_id: number;
  name: string = '';
  type: string = '';
  unit: string = '';
}
